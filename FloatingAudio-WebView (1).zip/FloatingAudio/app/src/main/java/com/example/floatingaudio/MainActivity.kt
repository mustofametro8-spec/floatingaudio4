package com.example.floatingaudio

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1
            )
        }
    }

    inner class Bridge {
        @JavascriptInterface fun isOverlayGranted() = Settings.canDrawOverlays(this@MainActivity)
        @JavascriptInterface fun isRunning() = OverlayService.isRunning

        @JavascriptInterface fun openOverlay() {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } else {
                    ContextCompat.startForegroundService(
                        this@MainActivity, Intent(this@MainActivity, OverlayService::class.java)
                    )
                    moveTaskToBack(true) // langsung kembali agar bisa buka game
                }
            }
        }

        @JavascriptInterface fun closeOverlay() {
            runOnUiThread { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
